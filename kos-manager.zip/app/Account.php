<?php

namespace App;

use Illuminate\Database\Eloquent\SoftDeletes;

class Account extends Model
{
    public function users()
    {
        return $this->hasMany(User::class);
    }

    public function organizations()
    {
        return $this->hasMany(Organization::class);
    }

    public function renters()
    {
        return $this->hasMany(Renter::class);
    }

    public function contacts()
    {
        return $this->hasMany(Contact::class);
    }

}
